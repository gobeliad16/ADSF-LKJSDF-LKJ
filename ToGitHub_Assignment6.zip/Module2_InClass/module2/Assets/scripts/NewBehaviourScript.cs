﻿using UnityEngine;
using System.Collections;

public class NewBehaviourScript : MonoBehaviour {
	
	Rigidbody2D characterRigidBody;
	Transform characterTransform; 
	float			hFactor;    // used to create movement
	public float 	hScale;     // sets the speed of movement
	float			vVelocity;  // used to jump
	public float	jumpValue;  // sets the height of jump

    public Transform groundCheck;       
    public float groundCheckRadius;     
    public LayerMask whatIsGround;       
    private bool grounded;    // for is true WHILE on ground, false WHILE NOT on ground
    private bool canDoubleJump;       // used to allow player to jump once while in the air
    


	// Use this for initialization
	void Start () {
		characterTransform = gameObject.transform;
		characterRigidBody = gameObject.GetComponent<Rigidbody2D> ();
/*
        void FixedUpdate(){
            grounded = PhysicsMaterial2D.OverlapCircle(groundCheck.position, groundCheckRadius, whatIsGround);
        }
 */ 
	}
	
	// Update is called once per frame
	void Update () {
        // checks if player is on the ground
        grounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, whatIsGround);

		// horizontal movement code
		print(Input.GetAxis ("Horizontal"));
		hFactor = Input.GetAxis ("Horizontal") * hScale;

		// vertical movement code (jumping *jump-jump*)
        if (canDoubleJump)
        {
            if ( Input.GetKeyDown(KeyCode.Space) ){
                vVelocity = jumpValue;
                canDoubleJump = false;
            }
            else
            {
                vVelocity = 0;
            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.Space) && grounded)
            {
                vVelocity = jumpValue;
                canDoubleJump = true;
            }
            else
            {
                vVelocity = 0;
            }
        }

		characterRigidBody.velocity = characterRigidBody.velocity + new Vector2 (0, vVelocity);
		characterTransform.position = new Vector2 (hFactor + characterTransform.position.x, characterTransform.position.y);
	}

}
